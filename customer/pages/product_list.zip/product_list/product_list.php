<div class="content__container__main">
  <div class="content__container__main__header">Products List</div>
    <div class="content__container__main__products" id="product_container">
        <!-- Item Template -->

        <div class="content__container__main__products__item" onclick="window.location='?mod=product&id=1' " data-product="1">
            <div class="content__container__main__products__item__image">
                <img src="" alt="product image" />
                <div class="content__container__main__products__item__price-circle">
                    <div class="content__container__main__products__item__price">₱ 50</div>
                </div>
            </div>
            <div class="content__container__main__products__item__name">Sample Item</div>
        </div>
        <!-- Item Ends Here -->

        </div>
      </div>
    </div>
</div>
